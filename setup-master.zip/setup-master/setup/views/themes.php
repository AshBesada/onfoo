<div
    class="row hide"
    data-html="themes"
></div>
<div class="panel panel-install">
    <button
        class="btn btn-default btn-sm"
        data-install-control="install-core"
    ><?= lang('button_clean_install') ?></button>
    <p>Install TastyIgniter without any extensions or themes.</p>
</div>
