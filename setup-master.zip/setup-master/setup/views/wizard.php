<div class="row bs-wizard">
    <div class="col-xs-2 bs-wizard-step" data-wizard="requirement">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
    <div class="col-xs-3 bs-wizard-step" data-wizard="database">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
    <div class="col-xs-3 bs-wizard-step" data-wizard="settings">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
    <div class="col-xs-2 bs-wizard-step" data-wizard="install">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
    <div class="col-xs-2 bs-wizard-step" data-wizard="proceed">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
</div>
